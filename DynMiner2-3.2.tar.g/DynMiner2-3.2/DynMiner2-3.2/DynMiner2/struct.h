#pragma once

struct MemoryStruct {
	char* memory;
	size_t size;
};