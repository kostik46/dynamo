#pragma once

#define MINER_VERSION "3.2"
